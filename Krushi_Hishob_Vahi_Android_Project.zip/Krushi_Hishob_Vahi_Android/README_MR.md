# कृषी हिशेब वही — Android प्रोजेक्ट

हा नवीन Android अॅपचा प्राथमिक स्रोत प्रकल्प आहे. अॅप ऑफलाइन चालते आणि नोंदी फोनवरील अॅपच्या स्थानिक साठवणीत (localStorage) ठेवते.

## अॅपमध्ये
- शेत/पिकानुसार खर्च, उत्पन्न आणि कामाची नोंद
- खत, औषधे, मजुरी, डिझेल, वाहतूक इत्यादी श्रेणी
- एकूण खर्च, एकूण उत्पन्न आणि शिल्लक रक्कम
- नोंदी पाहणे व हटवणे
- इंटरनेटशिवाय वापर

## APK तयार करण्याची सोपी ऑनलाइन पद्धत
1. GitHub वर नवीन repository तयार करा.
2. या ZIP मधील फाइल्स extract करून repository मध्ये upload करा. ZIP स्वतः ZIP म्हणून upload करू नका.
3. repository चे नाव काहीही ठेवू शकता; branch चे नाव `main` ठेवा.
4. GitHub मध्ये **Actions** उघडा. `Build Android APK` workflow निवडा आणि **Run workflow** दाबा. फाइल्स `main` वर push केल्यास workflow आपोआपही चालेल.
5. build पूर्ण झाल्यावर त्या workflow run च्या पानाच्या खाली **Artifacts** मध्ये `Krushi-Hishob-Vahi-APK` डाउनलोड करा.
6. ZIP artifact extract करा. त्यातील `app-debug.apk` Android फोनवर उघडून install करा. फोनने परवानगी विचारल्यास फक्त GitHub वरून मिळालेल्या स्वतःच्या build साठीच install permission द्या.

## महत्त्वाच्या सूचना
- हा debug APK आहे, Play Store साठी signed release APK नाही.
- नोंदी या फोनवरच राहतात. अॅप uninstall केल्यास किंवा अॅपचा data clear केल्यास नोंदी नष्ट होऊ शकतात.
- सध्या cloud sync/automatic backup नाही. महत्त्वाच्या नोंदींची वेगळी प्रत ठेवणे योग्य.
- हा पहिला प्राथमिक build आहे. तुमच्या फोनवर install करून तपासल्यानंतर पुढील सुधारणा करता येतील.
